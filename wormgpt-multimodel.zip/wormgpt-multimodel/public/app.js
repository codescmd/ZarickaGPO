const $ = (s) => document.querySelector(s);
const state = { providers: [], messages: [], chats: [], activeChat: null, busy: false };
const STORAGE_KEY = "wormgpt.multi.chats.v1";

function saveChats() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.chats));
}
function loadChats() {
  try { state.chats = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { state.chats = []; }
  renderHistory();
}
function newChat() {
  state.activeChat = null;
  state.messages = [];
  $("#messages").innerHTML = "";
  $("#welcome").hidden = false;
  renderHistory();
}
function renderHistory() {
  const host = $("#history");
  host.innerHTML = "";
  state.chats.slice().reverse().forEach(chat => {
    const b = document.createElement("button");
    b.textContent = chat.title || "New conversation";
    b.className = chat.id === state.activeChat ? "active" : "";
    b.addEventListener("click", () => openChat(chat.id));
    host.append(b);
  });
}
function openChat(id) {
  const chat = state.chats.find(c => c.id === id);
  if (!chat) return;
  state.activeChat = id;
  state.messages = [...chat.messages];
  $("#welcome").hidden = true;
  $("#messages").innerHTML = "";
  state.messages.forEach(m => renderMessage(m.role, m.content, m.provider, m.model));
  renderHistory();
}
function persistCurrent() {
  if (!state.messages.length) return;
  let chat = state.chats.find(c => c.id === state.activeChat);
  if (!chat) {
    chat = { id: crypto.randomUUID(), title: state.messages.find(m => m.role === "user")?.content.slice(0, 42) || "New conversation", messages: [], updated: Date.now() };
    state.activeChat = chat.id;
    state.chats.push(chat);
  }
  chat.messages = state.messages.slice(-60);
  chat.updated = Date.now();
  saveChats();
  renderHistory();
}
function renderMessage(role, content, provider, model, isError = false) {
  const row = document.createElement("article");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "YOU" : "AI";
  const body = document.createElement("div");
  body.className = "bubble" + (isError ? " error" : "");
  if (provider) {
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent = `${provider} · ${model || ""}`;
    body.append(meta);
  }
  const text = document.createElement("div");
  text.textContent = content;
  body.append(text);
  row.append(avatar, body);
  $("#messages").append(row);
  row.scrollIntoView({ behavior: "smooth", block: "end" });
  return row;
}
function fillModels() {
  const provider = state.providers.find(p => p.id === $("#providerSelect").value);
  const select = $("#modelSelect");
  select.innerHTML = "";
  (provider?.models || []).forEach(m => {
    const option = document.createElement("option");
    option.value = m.id; option.textContent = m.name;
    select.append(option);
  });
  $("#providerHint").textContent = provider?.configured ? "API KEY CONNECTED" : "API KEY NOT CONFIGURED";
  $("#providerHint").style.color = provider?.configured ? "var(--green)" : "#ffb86b";
}
async function loadConfig() {
  const res = await fetch("/api/config");
  const data = await res.json();
  state.providers = data.providers || [];
  const select = $("#providerSelect");
  select.innerHTML = "";
  state.providers.forEach(p => {
    const option = document.createElement("option");
    option.value = p.id; option.textContent = p.name;
    select.append(option);
  });
  const preferred = state.providers.find(p => p.configured) || state.providers[0];
  if (preferred) select.value = preferred.id;
  fillModels();
  const ready = state.providers.filter(p => p.configured).length;
  $("#systemStatus").textContent = `${ready} provider(s) configured`;
  $("#systemStatus").previousElementSibling.style.background = ready ? "var(--green)" : "#ffb86b";
}
async function sendMessage(content) {
  if (state.busy || !content.trim()) return;
  const provider = $("#providerSelect").value;
  const model = $("#modelSelect").value;
  const config = state.providers.find(p => p.id === provider);
  if (!config?.configured) {
    renderMessage("assistant", `ยังไม่ได้ตั้งค่า API key ของ ${config?.name || provider} — เพิ่ม key ในไฟล์ .env แล้วรีสตาร์ตเซิร์ฟเวอร์`, null, null, true);
    return;
  }
  $("#welcome").hidden = true;
  state.messages.push({ role: "user", content });
  renderMessage("user", content);
  const context = state.messages.slice(-20).map(({ role, content }) => ({ role, content }));
  const loading = renderMessage("assistant", "กำลังประมวลผล…", config.name, model);
  loading.querySelector(".bubble div:last-child").className = "typing";
  state.busy = true; $("#sendBtn").disabled = true;
  try {
    const res = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider, model, messages: context })
    });
    const data = await res.json();
    loading.remove();
    if (!res.ok) throw new Error(data.error || "Request failed");
    state.messages.push({ role: "assistant", content: data.content, provider: data.provider, model: data.model });
    renderMessage("assistant", data.content, data.provider, data.model);
    persistCurrent();
  } catch (err) {
    loading.remove();
    renderMessage("assistant", err.message || "เกิดข้อผิดพลาด", null, null, true);
    state.messages.pop();
  } finally {
    state.busy = false; $("#sendBtn").disabled = false; $("#prompt").focus();
  }
}
$("#chatForm").addEventListener("submit", e => {
  e.preventDefault();
  const input = $("#prompt");
  const value = input.value.trim();
  if (!value) return;
  input.value = ""; input.style.height = "auto"; $("#charCount").textContent = "0 / 12000";
  sendMessage(value);
});
$("#prompt").addEventListener("input", e => {
  e.target.style.height = "auto";
  e.target.style.height = `${Math.min(e.target.scrollHeight, 180)}px`;
  $("#charCount").textContent = `${e.target.value.length} / 12000`;
});
$("#prompt").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#chatForm").requestSubmit(); }
});
$("#providerSelect").addEventListener("change", fillModels);
$("#newChat").addEventListener("click", () => { newChat(); $("#sidebar").classList.remove("open"); });
$("#clearHistory").addEventListener("click", () => {
  if (confirm("ลบประวัติแชตที่เก็บในเบราว์เซอร์ทั้งหมด?")) {
    state.chats = []; saveChats(); newChat();
  }
});
$("#menuBtn").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
document.querySelectorAll("[data-prompt]").forEach(b => b.addEventListener("click", () => {
  $("#prompt").value = b.dataset.prompt; $("#prompt").focus();
  $("#charCount").textContent = `${$("#prompt").value.length} / 12000`;
}));
loadChats();
loadConfig().catch(() => { $("#systemStatus").textContent = "API server unavailable"; });
