import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      connectSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "256kb" }));

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",").map(v => v.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.length && !allowedOrigins.includes(origin)) {
    return res.status(403).json({ error: "Origin not allowed" });
  }
  next();
});

const limiter = rateLimit({
  windowMs: 60_000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Try again in a minute." }
});
app.use("/api/chat", limiter);

const PROVIDERS = {
  groq: {
    label: "Groq",
    baseURL: "https://api.groq.com/openai/v1/chat/completions",
    key: () => process.env.GROQ_API_KEY,
    models: [
      { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B" },
      { id: "openai/gpt-oss-20b", name: "GPT-OSS 20B" }
    ]
  },
  openrouter: {
    label: "OpenRouter",
    baseURL: "https://openrouter.ai/api/v1/chat/completions",
    key: () => process.env.OPENROUTER_API_KEY,
    models: [
      { id: "meta-llama/llama-3.3-70b-instruct:free", name: "Llama 3.3 70B (Free)" },
      { id: "google/gemma-3-27b-it:free", name: "Gemma 3 27B (Free)" },
      { id: "deepseek/deepseek-r1:free", name: "DeepSeek R1 (Free)" }
    ]
  },
  gemini: {
    label: "Gemini",
    baseURL: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    key: () => process.env.GEMINI_API_KEY,
    models: [
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash" },
      { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash" }
    ]
  }
};

app.get("/api/config", (_req, res) => {
  res.json({
    providers: Object.entries(PROVIDERS).map(([id, p]) => ({
      id, name: p.label, configured: Boolean(p.key()),
      models: p.models
    }))
  });
});

const messageSchema = z.object({
  provider: z.enum(["groq", "openrouter", "gemini"]),
  model: z.string().min(1).max(120),
  messages: z.array(z.object({
    role: z.enum(["system", "user", "assistant"]),
    content: z.string().min(1).max(12000)
  })).min(1).max(30)
});

app.post("/api/chat", async (req, res) => {
  const parsed = messageSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
  }
  const { provider: providerId, model, messages } = parsed.data;
  const provider = PROVIDERS[providerId];
  if (!provider.models.some(m => m.id === model)) {
    return res.status(400).json({ error: "Model is not in the server allowlist." });
  }
  const apiKey = provider.key();
  if (!apiKey) return res.status(503).json({ error: `${provider.label} is not configured. Add its API key to .env.` });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60_000);
  try {
    const headers = { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` };
    if (providerId === "openrouter") {
      headers["HTTP-Referer"] = `http://localhost:${PORT}`;
      headers["X-Title"] = "WormGPT Multi-Model Chat";
    }
    const upstream = await fetch(provider.baseURL, {
      method: "POST", headers, signal: controller.signal,
      body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 2048 })
    });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { error: raw.slice(0, 500) }; }
    if (!upstream.ok) {
      const detail = data?.error?.message || data?.error || `Provider returned ${upstream.status}`;
      return res.status(upstream.status === 429 ? 429 : 502).json({ error: String(detail).slice(0, 700) });
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content.trim()) {
      return res.status(502).json({ error: "Provider returned an empty or unsupported response." });
    }
    res.json({ content, provider: provider.label, model });
  } catch (err) {
    const message = err.name === "AbortError" ? "Provider request timed out." : "Could not reach the AI provider.";
    res.status(502).json({ error: message });
  } finally {
    clearTimeout(timeout);
  }
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`WormGPT Multi-Model running at http://localhost:${PORT}`));
